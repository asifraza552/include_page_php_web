<div class="navbar">
        <a class="active" href="index.php">home</a>
        <a href="about.php">about</a>
        <a href="contact.php">contact</a>
    </div>