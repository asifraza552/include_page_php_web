<div class="footer">
  <h2>(: asif raza tecnical :)</h2>
</div>