<div class="header">
    <h1>my php website</h1>
    </div>
