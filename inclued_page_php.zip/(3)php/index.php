   <?php include ("doc.php"); ?>
   <link rel="stylesheet" href="style.css">
    <title>my home php page</title>
    
</head>
<body>

   <?php include ("h.php"); ?>
   <?php include ("nav.php"); ?>

    <div class="row">
        <div class="main">
            <h2>home</h2>
            <p>my home page content (1)</p>
            <p>my home page content (2)</p>
            <p>my home page content (3)</p>
            <p>my home page content (4)</p>
            <p>my home page content (5)</p>
            <p>my home page content (6)</p>
            <p>my home page content (7)</p>
        </div>
    </div>
    <?php include("f.php");?>
      </div>
      </div>
</body>
</html>