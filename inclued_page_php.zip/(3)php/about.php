<?php include ("doc.php"); ?>
  <title>my home php page</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include ("h.php"); ?>
    <?php include ("nav.php"); ?>
    <div class="row">
        <div class="main">
            <h2>about us</h2>
            <p>my about us page content (1)</p>
            <p>my about us page content (2)</p>
            <p>my about us page content (3)</p>
            <p>my about us page content (4)</p>
            <p>my about us page content (5)</p>
            <p>my about us page content (6)</p>
            <p>my about us page content (7)</p>
        </div>
    </div>
    <?php include("f.php");?>
</div>
</body>
</html>